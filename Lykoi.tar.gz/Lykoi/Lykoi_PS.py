#!/usr/bin/python3
import socket
import os

#Clear
os.system('clear')

# PRESENTATION BANNER
banner = (''' 

[*] Scanning local ports, give me a second. 

 ''')

print(banner)

#Script start
ip = '127.0.0.1'
port_list = [20, 80, 8080, 139, 445, 23, 22, 21, 443]

for port in port_list:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    results = s.connect_ex((ip, port))

    if results == 0:
        print('*' * 40)
        print('port', port, 'is open')
        print('*' * 40)
    else:
        print('port', port, 'is closed')
