#!/usr/bin/python3
#modules
import socket
import os
import ipaddress

#clear
os.system('clear')

#Start script
def target():
    while True:
        try:
            val = input("Please enter an ip address of the server you wish to connect with: ")
            return ipaddress.ip_address(val)
        except ValueError:
            print("Not a valid IP address. Eg: 192.168.0.1")

def portscan(port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((target, port))

